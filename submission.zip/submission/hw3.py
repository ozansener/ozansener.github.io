from Bio.SVDSuperimposer import SVDSuperimposer
import numpy as np
import sys
import getopt

def read_pdb(file_name):
	coordinates = []
	for _line in open(file_name):
		if len(_line)>6:
			_id = _line[0:6]
			if 'ATOM' in _id:
				# check CA
				_type = _line[12:16]
				if _type.strip() == 'CA':
					# Read the coordinates					
					_x = float(_line[30:38].strip())
					_y = float(_line[38:46].strip())
					_z = float(_line[46:54].strip())
					coordinates.append([_x,_y,_z])
	return coordinates


def align_files(file_name_1, file_name_2):
	points1 = read_pdb(file_name_1)
	points2 = read_pdb(file_name_2)

	min_rmss = 1e20

	# Find the seed
	for id1 in range(len(points1)-9):
		for id2 in range(len(points2)-9):
			sup = SVDSuperimposer() 
			sup.set(np.array(points1[id1:id1+10],'f'), np.array(points2[id2:id2+10],'f')) 
			sup.run() 
			_rms = sup.get_rms() 

			if _rms < min_rmss:
				min_rmss = _rms
				seed = (id1, id2)

	# Extend it
	ext = 0
	last_rms = min_rmss
	last_score = 10/min_rmss

	while True:
		# Start extending
		ext = ext + 2

		new_id_1 = seed[0]- (ext/2)
		new_id_2 = seed[1]- (ext/2)

		new_length = 10 + ext

		if new_id_1 < 0 or new_id_2 < 0:
			break

		if new_id_1+new_length >= len(points1) or new_id_2+new_length >= len(points2):
			break

		sup = SVDSuperimposer() 
		sup.set(np.array(points1[new_id_1:new_id_1+new_length],'f'), 
			np.array(points2[new_id_2:new_id_2+new_length],'f')) 
		sup.run() 

		new_rms = sup.get_rms() 
		new_score = new_length/new_rms
		
		if new_score >= last_score or new_rms <= 1.0:
			last_score = new_score
			last_rms = new_rms
			last_ext = ext
			last_length = new_length
		else:
			break
	return seed[0]-last_ext/2, seed[1]-last_ext/2, last_length, last_score, last_rms

def main(argv):
	firstfile = ''
	secondfile = ''
	try:
		opts, args = getopt.getopt(argv,"f:s:",["firstfile=","secondfile="])
	except getopt.GetoptError:
		print 'hw3.py -f <firstfile> -s <secondfile>'
   	for opt, arg in opts:
  		if opt in ("-f", "--firstfile"):
  			firstfile = arg
    	if opt in ("-s", "--secondfile"):
    		secondfile = arg
   
   	id1, id2, length, score, rms = align_files(firstfile, secondfile)
   	print 'Alignment results:'
   	print '======================'
   	print 'Alignment length: {}'.format(length)
   	print 'Aligned amino acids:'
	print 'Prot1: {} {}-{}'.format(firstfile, id1, id1+length-1)
	print 'Prot2: {} {}-{}'.format(secondfile, id2, id2+length-1)
	print 'RMSD: {}'.format(rms)
	print 'Alignment Score: {}'.format(score)

if __name__ == "__main__":
	main(sys.argv[1:])
